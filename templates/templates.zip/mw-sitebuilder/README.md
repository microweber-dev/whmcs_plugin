# Microweber WHMCS Template
## How to install Microweber WHMCS Template
1. Upload files from this repo in whmcs dir **/templates/microweber**
